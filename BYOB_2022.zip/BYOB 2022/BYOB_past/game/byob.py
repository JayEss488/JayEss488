#js
#build your own battleship (project)

from time import time
import random,math
import pygame as pg
from pygame.locals import(
    RLEACCEL,
    K_ESCAPE,
    KEYDOWN,
    QUIT)

BLSIZE=30
FRAMERATE=60
BULLETSPEED=round(1000/FRAMERATE)
DESIGNROWS=2
DESIGNCOLS=3
SHIPSPEED=8
WEAPONS=["basicturret","mortar","rocketturret"]
FLOATINGS=["mediumflt","smallflt","largeflt","propellor"]
ARMOURS=["metalarmour","woodarmour"]
ENGINES=["smallengine","mediumengine"]

bullets=pg.sprite.Group()
myweapons=pg.sprite.Group()
PATH="game\\"

###########################setup display
pg.init()
pg.display.set_caption("Build your Own Battleship")
monitor=pg.display.Info()
monw=monitor.current_w
monh=monitor.current_h
screen=pg.display.set_mode((monw,monh),pg.RESIZABLE)#setting window size
bgd=pg.image.load(PATH+"sea_bgd.jpg")
bgd=pg.transform.scale(bgd, (monw,monh))
bgrect=bgd.get_rect()
bgrect.x=0
bgrect.y=0
MAPSIZE=monw*2
icon=pg.image.load(PATH+"shell1.png")
pg.display.set_icon(icon)











##################utility functions
def toscreenpos(where,yours=True):#where is x,y eg 2,0 for top right (y is 0 at top)
    if yours:
        validarea=[200,600-BLSIZE*2]#top left
    else:
        validarea=[800,600-BLSIZE*2]#to right
        
    x=validarea[0]+where[0]*BLSIZE#so left + how far along
    y=validarea[1]+where[1]*BLSIZE
    return x,y
    

def checkcam(campos,xcoord,size):
    farfromleft=xcoord
    farfromright=monitor.current_w-xcoord-size
    if farfromleft<0:#ship to left of screen, close to end so best view ahead
        cammotion=farfromleft
    elif farfromright<=350:#right=need positive
        cammotion=350-farfromright#ship RIGHT of screen
    else:
        cammotion=0
        
    campos+=cammotion
    if campos<0:#far left of map
        campos=0
    elif campos>MAPSIZE:#far right
        campos=MAPSIZE

    return cammotion,campos#taken from rect so if 10 ship moves 10 left, if to LEFT of screen want NEGATIVE so ship goes right


def displayship(ship,shipgroup,yours=True):# ship=[[mortar, medflt],[..],[..]]
    floatwait=[]
    outcount=0#is x
    for y in ship:#outer list is cols ie 3 sets of down 2s ie x
        incount=0#is y
        for x in y:#each component
            if x=="mediumflt":
                size=3
            else:
                size=1
                
            if yours:
                position=[outcount,incount]#x is where[0]= incount=
            else:
                position=[DESIGNCOLS-outcount,incount]
            
            #####find out which blk and create instance
            if x in ENGINES:
                eng=engine(x,position,size,yours)#invert y so top list stays top screen
                shipgroup.add(eng)
                    
            elif x in WEAPONS:
                weap=weapon(x,position,size,yours)#x is basicturret
                if yours:
                    myweapons.add(weap)
                shipgroup.add(weap)
            elif x in FLOATINGS:#MAKE LIST
                flt=floating(x,position,size,yours)#mediumflt
                floatwait.append(flt)
            elif x in ARMOURS:
                arm=armour(x,position,size,yours)
                shipgroup.add(arm)
            elif x=="":#blank space
                pass
            incount+=1
        outcount+=1
    for each in floatwait:
        shipgroup.add(each)#so flt blocks blitted last
        
def calcmiss(x,angle,target,targetmovement):#of gun bullet comes from, enangle=calcmiss(self.rect.x,self.rect.y,enangle)#pos of gun-> pos of bullet, bulletspeed, angle
    speedy=BULLETSPEED*round(math.sin(angle/180*math.pi),3)#fr=60
    speedx=-BULLETSPEED*round(math.cos(angle/180*math.pi),3)#init speeds
    time=2*speedy*FRAMERATE/5#num frames
    
    bulldist=time*speedx#-ve
    farfrom=x+bulldist-target+500+(targetmovement*-time)


    mult=1#-1000 is too far, 100 is too short
    if farfrom>-100 and farfrom<250:#should hit, target-x= how far has to go
        return angle
    elif farfrom>-300:#too short
        if farfrom>700:
            mult=2
        if angle<45:
            return min(angle+5*mult,45)#raise turret to up dist
        else:
            return max(angle-5*mult,45)#lower turret to up dist
    else:#too far
        if farfrom<-2000:
            mult=4
        elif farfrom<-1500:
            mult=3
        elif farfrom<-600:
            mult=2
        if angle>45:
            return min(angle+5*mult,85)#if 90 hit self
        else:
            return max(angle-5*mult,0)
    
    

def automateen(posyour,posen):#enmove,enangle=
    distancebn=posen-posyour-150#+ve if enemy to right, -150 for ship length
    if distancebn>800:#move bacnkwards
        enmove=-SHIPSPEED/2
    elif distancebn<500:
        enmove=SHIPSPEED/2#want to be far in front of you
    else:
        enmove=0
        
    return enmove
        
        






#####################lots of classes
class bullet(pg.sprite.Sprite):
    def __init__(self,whichweapon, whichshell,angle,yours):
        super(bullet,self).__init__()
        self.yours=yours
        modyours=(1 if yours else -1)
        self.size,self.damage={"rocket":((160,40),40),"shell1":((50,16),20),"mortarshell":((80,30),30)}[whichshell]
        self.mod={"basicturret":[-20,75],"rocketturret":[-10,40],"mortar":[-10,100]}[whichweapon.name]#mod init bullet pos- NOT scaled
        ############load image and set motion
        self.origsfc=pg.image.load(PATH+whichshell+".png").convert_alpha()
        self.origsfc=pg.transform.scale(self.origsfc,(int(self.size[0]*BLSIZE/100),int(self.size[1]*BLSIZE/100)))
        if not yours:
            self.origsfc=pg.transform.flip(self.origsfc,True,False)
        self.rect=self.origsfc.get_rect()

        self.angle=angle*5#the angle the gun points

        extrax=70*round(math.cos(self.angle/180*math.pi),3)
        extray=100*round(math.sin(self.angle/180*math.pi),3)
        self.rect.x=whichweapon.gunrect.x+extrax+self.mod[0]
        self.rect.y=whichweapon.gunrect.y-extray+self.mod[1]
        self.exploded=0
        self.arm=time()#0.5 sec before can explode
        

        ##speed needs to be dep on angle        total speed ie hypotenuse=30 y=hyp sin angle, x=hyp cos angle
        self.speedx=BULLETSPEED*round(math.cos(self.angle/180*math.pi),3)
        if not yours:
            self.speedx=-self.speedx
        self.speedy=BULLETSPEED*round(math.sin(self.angle/180*math.pi),3)

    def update(self):
        if self.exploded==0:
            self.rect.x+=self.speedx
            self.rect.y-=self.speedy#minus to go up initially

            if self.speedx!=0:
                self.angle=round(math.atan(self.speedy/self.speedx)*180/math.pi)
                if self.angle==90:
                    self.angle=89        
            time=1/FRAMERATE
            self.speedy-=time*10#gravity doenst have to be 9.81
        
            if self.rect.x>screen.get_width()+100 or self.rect.x<-100:#if bullet far outside screen
                self.explode(noanim=True)
                self.killnext=True
            self.sfc=pg.transform.rotate(self.origsfc,self.angle)



            
        else:
            self.exploded+=1
            if self.exploded>=10:
                self.kill()
            else:
                calc=self.exploded**2
                self.sfc=pg.transform.scale(self.origsfc,(calc,calc))
                self.rect.x-=int(calc/8)
                self.rect.y-=int(calc/8)#1 when *2 so radius expansion
        screen.blit(self.sfc,self.rect)

    def explode(self,noanim=False):
        if not noanim:
            self.origsfc=pg.image.load(PATH+"explode1.png").convert_alpha()
            self.speedx=self.speedy=0
            self.exploded=1
        else:
            self.kill()











            
class block(pg.sprite.Sprite):#armour,engine
    def __init__(self,what,where,size,yours):#where as grid pos
        super(block,self).__init__()
        self.yours=yours
        self.sfc=pg.image.load(PATH+what+".png").convert_alpha()
        if not yours:
            self.sfc=pg.transform.flip(self.sfc,True,False)

        self.sfc=pg.transform.scale(self.sfc,(BLSIZE*size,int(BLSIZE*size*self.sfc.get_height()/self.sfc.get_width())))#keep aspect ratio on width
        self.rect=self.sfc.get_rect()
        self.rect.x,self.rect.y=toscreenpos(where,yours)
        if size!=1 and not yours:
            self.rect.x-=BLSIZE*(size-1)#-1 or x works
        self.size=size
        self.name=what

    def update(self,movement):
        self.rect.x+=movement

    def takedamage(self,damage,myship,enships):
        if damage<self.hp:
            self.hp-=damage
        else:
            self.kill()
            end=True
            if self.yours:
                which=myship
            else:
                which=enships
            for x in which:
                if x.name=="mediumflt" or x.name=="smallflt":#if any flt blocks left on ship
                    end=False
                    break
            if end==True:
                endsoon=time()
                if self.yours:
                    for each in myship:#remove artifact parts
                        each.kill()
                else:
                    for each in enships:
                        each.kill()
                return endsoon,not(self.yours)#ie who wins

                
                
                
            
                
            
    



class floating(block):
    def __init__(self,what,where,size,yours):
        block.__init__(self,what,where,size,yours)
        if what=="mediumflt":#adjust certain imgs
            self.hp=150
            self.rect.y-=0.1*BLSIZE
        if what=="smallflt":
            self.rect.y-=0.4*BLSIZE
            self.rect.x+=4
            self.hp=40

class armour(block):
    def __init__(self,what,where,size,yours):
        block.__init__(self,what,where,size,yours)
        self.hp=200

class engine(block):
    def __init__(self,what,where,size,yours):
        block.__init__(self,what,where,size,yours)
        self.hp=60
        self.yours=yours
        self.rect.y+=0.4*BLSIZE
        self.propsfc=pg.image.load(PATH+"propellor.png").convert_alpha()
        if not yours:
            self.propsfc=pg.transform.flip(self.propsfc,True,False)
        self.propsfc=pg.transform.scale(self.propsfc,(BLSIZE,BLSIZE))
        self.proprect=self.propsfc.get_rect()
        
        

    def update(self,movement):
        self.rect.x+=movement
        if self.yours:
            self.proprect.center=(self.rect.x,self.rect.y+BLSIZE*1.2)#note: only works if engine at BACK
        else:
            self.proprect.center=(self.rect.x+(BLSIZE*self.size),self.rect.y+BLSIZE*1.2)#+10 is -10 *-1
        screen.blit(self.propsfc,self.proprect)


class weapon(block):
    def __init__(self,what,where,size,yours):#what is basicturret, rocketturret, mortar
        block.__init__(self,what,where,size,yours)
        if what=="mortar":
            self.rect.y+=0.6*BLSIZE
        #gun adjusts
        self.hp,self.fires,self.adjust={"basicturret":(45,"shell1",[35,-140]),"mortar":(60,"mortarshell",[-40,-135]),"rocketturret":(45,"rocket",[-50,-95])}[what]
        self.adjust[0]*=BLSIZE/100
        self.adjust[1]*=BLSIZE/100
        self.yours=yours
        
        ###############gun part of turret
        ranges={"basicturret":[-1,16],"rocketturret":[0,17],"mortar":[8,18]}
        self.thisrange=ranges[what]
        self.guns=[]
        for x in range(self.thisrange[0],self.thisrange[1]+1):#first animation frame to last
            newgun=pg.image.load(PATH+what+'anim\\gun'+str(x)+'.png')#-1 to 16
            newgun=pg.transform.scale(newgun,(BLSIZE*2,BLSIZE*2))
            self.guns.append(newgun)
        self.index=self.angle=0        
        self.gunimg=self.guns[self.index]


    def update(self,aimangle,movement):
        indexangle=int(aimangle/5)#go from 45-> index 9
        if indexangle>=self.thisrange[0] and indexangle<=self.thisrange[1]:#thisrange[0] is eg 0 or -1, thisrange[1] is eg 17
            self.index=indexangle-self.thisrange[0]#go from wrong index 9-> right index eg 8
        elif indexangle<self.thisrange[0]:#if angle lower than gun can go
            self.index=0
        else:
            self.index=len(self.guns)-1#last in list
            #when angle is just below eg indexangle=thisrange[0]
        
        self.gunimg=self.guns[self.index]#set anim frame
        if not self.yours:
            self.gunimg=pg.transform.flip(self.gunimg,True,False)
            
        self.rect.x+=movement
        if not self.yours:
            self.gunrect=pg.Rect(self.rect.x-self.adjust[0]-BLSIZE,self.rect.y+self.adjust[1],100,100)
        else:
            self.gunrect=pg.Rect(self.rect.x+self.adjust[0],self.rect.y+self.adjust[1],100,100)#first set gun pos
        screen.blit(self.gunimg,self.gunrect)
        

    def fire(self):#add aimangle to this
        newbullet=bullet(self,self.fires,self.index+self.thisrange[0],self.yours)
        bullets.add(newbullet)











class aship():
    def __init__(self,ship,yours=True):
        self.rect=list(toscreenpos([0,0],yours))
        
        length=0
        for x in ship[-1]:#ie ship[1]
            if type(x)==int:
                length+=x-1#-1 to null +1 from commponent name that comes just before
            else:
                length+=1
        self.length=length*150#blocks ship from going off right end of screen
        
        
    def update(self,movement):
        self.rect[0]+=movement
        








def main(ship,enemyship):
    #assume grid of your ship is: 3x2 grid
    myship=pg.sprite.Group()
    myship.empty()
    myweapons.empty()
    
    enships=pg.sprite.Group() 
    displayship(ship,myship)
    ship1=aship(ship)
    displayship(enemyship,enships,0)
    enship=aship(enemyship,False)#instance
    
    aimangle=0#all guns as horizontal as poss
    angletime=time()
    firetime=time()
    enfiretime=time()
    
    enangle=45
    missdist=0  
    campos=0#out of 10000
    canmove=True
    movement=0
    lastenshot=None
    endsoon=None

    width,height=screen.get_size()
    running=True
    clock=pg.time.Clock()


    
    
    ###################pg events
    while running:
        clock.tick(FRAMERATE)
        for event in pg.event.get():
            if event.type==pg.QUIT:
                    running= False
                    
            elif event.type==KEYDOWN:
                if event.key== K_ESCAPE:
                    running=False


            ######control keys
        pressed=pg.key.get_pressed()        
        if pressed[pg.K_SPACE]:
            if time()-firetime>2:
                firetime=time()
                for x in myweapons:
                    x.fire()                    
        ############move ship
        if pressed[pg.K_a]:#move left
            movement=-SHIPSPEED
        elif pressed [pg.K_d]:
            movement=SHIPSPEED
        else:
            movement=0
        if pressed[pg.K_s]:#d moves turret -> and down, and angle down
            if time()-angletime>0.2:#only move 1 frame every 0.2 secs
                angletime=time()
                if aimangle>=0:
                    aimangle-=5              
        if pressed[pg.K_w]:
            if time()-angletime>0.2:
                angletime=time()
                if aimangle<=90:
                    aimangle+=5


            
##########end ctrl keys

                    
            elif event.type==pg.VIDEORESIZE:
                width,height=screen.get_size()
                

            elif event.type==pg.MOUSEBUTTONDOWN:
                    mouse=pg.mouse.get_pos()#[x,y]







        #################screen refresh 
        screen.blit(bgd,bgrect)
        
        for x in bullets:
            x.update()
                
            

        #########updating parts
        enmove=automateen(ship1.rect[0],enship.rect[0])
        justfired=False
        for each in myship,enships:
            for part in each:
                if part.yours:
                    if type(part).__name__=="weapon":
                        part.update(aimangle,movement)#weapon turret doesn't move extra bit left
                    else:
                        part.update(movement)
                else:
                    if type(part).__name__=="weapon":
                        part.update(enangle,enmove)
                        if time()-enfiretime>2:
                            justfired=True
                            part.fire()#only fires 1 weapon 4 enemy
                            enangle=calcmiss(part.rect.x,enangle,ship1.rect[0],movement)#pos of gun-> pos of bullet, bulletspeed, angle
                    else:
                        part.update(enmove)#update all on movement
                                
                screen.blit(part.sfc,part.rect)#all sprites must have surface and rect                        
                hit=pg.sprite.spritecollideany(part,bullets)#if any component hit by a bullet
                
                if hit and hit.exploded==0 and time()-hit.arm>0.2:#HIT=thebullet else None
                    hit.explode()
                    endsoon=part.takedamage(hit.damage,myship,enships)#None most of the time
                    if type(part).__name__!="wave":
                        pass
        if justfired:#so if en has multiple guns all fire
            enfiretime=time()

        #############cam, collide adjsuts
        cammotion,campos=checkcam(campos,ship1.rect[0],ship1.length)#rect[0] is x
        distancebn=enship.rect[0]-ship1.rect[0]-205#say 200-100-150=-50= collided= adjust by yourship going 50 back
        if distancebn>0:#no collision
            distancebn=0
        else:
            ship1.update(distancebn)#if distancebn -ve then go back
            
        for part in myship,enships,bullets:#camera
            for each in part:
                each.rect.x-=cammotion
                
        for part in myship:
            part.rect.x+=distancebn#collide and pushed <- back
        ship1.update(movement-cammotion)
        enship.update(enmove-cammotion)



        pg.display.update()
        if endsoon is not None:
            if time()-endsoon[0]>2:
                return endsoon[1]#ie winner
                    
    pg.quit()



#main([["","mediumflt"],["",""],["basicturret",""]],[["smallengine","mediumflt"],["metalarmour",""],["basicturret",""]])
