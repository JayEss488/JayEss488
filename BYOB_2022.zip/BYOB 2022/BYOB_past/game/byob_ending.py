import pygame as pg
from pygame.locals import(
    RLEACCEL,
    K_ESCAPE,
    KEYDOWN,
    QUIT)


WHITE=(255,255,255)
FRAMERATE=60
PATH="game\\"
###########################setup display
pg.init()
pg.display.set_caption("Build your Own Battleship")
monitor=pg.display.Info()
screen=pg.display.set_mode((monitor.current_w,monitor.current_h-60),pg.RESIZABLE)#setting window size
monw=monitor.current_w
monh=monitor.current_h
icon=pg.image.load(PATH+"shell1.png")
pg.display.set_icon(icon)

pg.font.init()
font=pg.font.SysFont("candara",60)
bigfont=pg.font.SysFont("times",150)












def main(winner):
    if winner:
        text="You win!"
        col=(0,200,150)
    else:
        text="You were destroyed."
        col=(255,0,0)
    running=True
    clock=pg.time.Clock()
    
    win=bigfont.render(text,False,col)          
    winrect=win.get_rect()
    winrect.center=(monitor.current_w/2,monitor.current_h/2-50)

    rtn=font.render("Return",False,(0,0,0))          
    rtnrect=rtn.get_rect()
    rtnrect.center=(monitor.current_w/2,monitor.current_h/2+100)#height 80, from monh/2+60 to monh/2+140

    end=font.render("Exit",False,(0,0,0))          
    endrect=end.get_rect()
    endrect.center=(monitor.current_w/2,monitor.current_h/2+200)

    
    
    ###################pg events
    while running:
        clock.tick(FRAMERATE)
        for event in pg.event.get():
            if event.type==pg.QUIT:
                    running= False         
            elif event.type==KEYDOWN:
                if event.key== K_ESCAPE:
                    running=False


            ######control keys
            elif event.type==pg.MOUSEBUTTONDOWN:
                    x,y=pg.mouse.get_pos()#[x,y]
                    if x>=monw/2-120 and x<=monw/2+120:
                        if y>=monh/2+60 and y<=monh/2+140:#return
                            return True
                        elif y>=monh/2+160 and y<=monh/2+240:
                            return False


        #################screen refresh 
        screen.fill(WHITE)
        screen.blit(win,winrect)
        pg.draw.rect(screen,(255,0,0),(monitor.current_w/2-120,monitor.current_h/2+60,240,80))
        screen.blit(rtn,rtnrect)
        pg.draw.rect(screen,(255,0,0),(monitor.current_w/2-120,monitor.current_h/2+160,240,80))
        screen.blit(end,endrect)


        


        pg.display.update()
    pg.quit()
