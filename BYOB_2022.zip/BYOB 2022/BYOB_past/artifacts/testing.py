#js
#build your own battleship (project)

import pygame as pg
from pygame.locals import(
    RLEACCEL,
    K_ESCAPE,
    KEYDOWN,
    QUIT)
WHITE=(255,255,255)
BLOCKHT=100


###########################setup display
pg.init()
pg.display.set_caption("Build your Own Battleship")
monitor=pg.display.Info()
screen=pg.display.set_mode((monitor.current_w,monitor.current_h-60),pg.RESIZABLE)#setting window size


icon=pg.image.load("basicturret.png")
pg.display.set_icon(icon)
pg.font.init()
font=pg.font.SysFont("arial",25)

##############################




class weapon(pg.sprite.Sprite):
    def __init__(self,xco,yco):#position
        super(weapon,self).__init__()
        #############main turret
        self.sfc=pg.image.load("mortar.png").convert_alpha()#load image
        self.sfc=pg.transform.scale(self.sfc,(50,50))
        #self.sfc=pg.transform.flip(self.sfc,True,False)#horizon,vert
        self.rect=self.sfc.get_rect()#admin
        self.rect.x=xco
        self.rect.y=yco
        
        
        ###############gun part of turret
        self.origgunsfc=pg.image.load("mortargun.png").convert_alpha()#pg.Surface((200,200))
        self.origgunsfc=pg.transform.scale(self.origgunsfc,(50,50))
        
        self.gunrect=self.origgunsfc.get_rect()
        self.gunrect.x=400
        self.gunrect.y=400
        self.origrect=(self.gunrect.x,self.gunrect.y)
        self.gunsfc=self.origgunsfc
        #self.gunsfc=pg.transform.rotate(self.origgunsfc,80)
        self.index=0


    def draw(self):#rotate gun by animation
        screen.blit(self.sfc,self.rect)
        screen.blit(self.gunsfc,self.gunrect)
        
##        pg.draw.rect(screen,(255,0,0),(500,500,5,5))#mid
##        pg.draw.rect(screen,(255,0,0),(self.gunrect.x+100,self.gunrect.y+200,5,5))#bottom mid
##        pg.draw.rect(screen,(255,0,0),(self.gunrect.x+200,self.gunrect.y+200,5,5))#base right
##        pg.draw.rect(screen,(255,0,0),(self.gunrect.x,self.gunrect.y+100,5,5))#center left
##        pg.draw.rect(screen,(255,0,0),(self.gunrect.x+200,self.gunrect.y+100,5,5))#center right


    def update(self):
        self.index+=1
        self.gunsfc=pg.transform.rotate(self.origgunsfc,self.index)
        









def main():
    ##################more setup
    width,height=screen.get_size()
    allsprite=pg.sprite.Group()
    weapon1=weapon(300,500)
    allsprite.add(weapon1)

    running=True
    clock=pg.time.Clock()


    
    
    ###################pg events
    while running:
        clock.tick(5)
        for event in pg.event.get():
            if event.type==pg.QUIT:
                    running= False
                    
            elif event.type==KEYDOWN:
                if event.key== K_ESCAPE:
                    running=False

            elif event.type==pg.VIDEORESIZE:
                width,height=screen.get_size()
                

            elif event.type==pg.MOUSEBUTTONDOWN:
                    mouse=pg.mouse.get_pos()#[x,y]







        #################screen refresh 
        screen.fill(WHITE)
        pg.draw.rect(screen,(0,0,255),(0,height-200,width,200))
        
        allsprite.update()
        for x in allsprite:
            x.draw()
        #allsprite.draw(screen)#only works if there is a weapon.image
            
        pg.display.update()
        

    pg.quit()
    
if __name__=='__main__':#this seems cool
    main()
                
