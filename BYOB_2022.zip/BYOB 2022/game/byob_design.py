#js
#build screen
from time import time
import math
import pygame as pg
from game import byob
from game import byob_ending
#import byob
from pygame.locals import(
    RLEACCEL,
    K_ESCAPE,
    KEYDOWN,
    QUIT)

FRAMERATE=60
PATH="game\\"
WEAPONS=["basicturret","mortar","rocketturret"]


pg.init()
pg.display.set_caption("Build your Own Battleship")
monitor=pg.display.Info()
monw=monitor.current_w
monh=monitor.current_h
screen=pg.display.set_mode((monw,monh+60),pg.RESIZABLE)#setting window size
icon=pg.image.load(PATH+"shell1.png")
pg.display.set_icon(icon)
pg.font.init()
font=pg.font.SysFont("candara",50)
bigfont=pg.font.SysFont("times",120)


COMPOWIDE=int(monw/8)
COMPONUM=6
COMPOHT=int(monh/COMPONUM)
TEXTX=monw*7/8
LOADADJUST=40

DESIGNWIDTH=int(monw*6/8)
DESIGNROWS=3
DESIGNCOLS=4
SQHEIGHT=int(monh/DESIGNROWS)
SQWIDTH=int(DESIGNWIDTH/DESIGNCOLS)


def makegrid():
    grid=[]
    for x in range(DESIGNCOLS):
        grid.append([])
        for y in range(DESIGNROWS):
            grid[x].append("")
    return grid

def anyfloat(grid):
    ship=genshipgrid(grid)
    ok=False
    for each in ship:
        for part in each:
            if part=="mediumflt" or part=="smallflt":
                ok=True

    for each in ship:#ie [gun,gun,float]
        if each[0]!="" and each[1]=="":#ie 1 block in mid air
            ok=False
        if each[0] in WEAPONS and each[1] in WEAPONS:
            ok=False#trying to stack guns!
    return ok#rejected
        

        
        

def loadship(num):
    num-=1#so first ship gotten st away
    ship=makegrid()
    countdown=DESIGNROWS*DESIGNCOLS
    outer=0
    inner=0
    with open("saves.txt") as file:
        for x in file:
            newx=x.strip()
            if num==0:
                ship[outer][inner]=newx
                inner+=1
                if inner==DESIGNROWS:
                    inner=0
                    outer+=1
                if outer>=DESIGNCOLS:#gotten that ship
                    break
            else:
                countdown-=1
                if countdown==0:
                    countdown=DESIGNROWS*DESIGNCOLS
                    num-=1
    return ship

def getrealnum(data,offset):
    posof1=-((data-1)/2)#4 nums-> -1.5 as 1 2 center 3 4
    if posof1%1!=0:#if a half
        posof1+=0.5
        offset+=70#half of 140 multiplier
    offnum=round(offset/140)
    realnum=int(offnum-posof1+1)#num you clicked on
    return realnum
                                
def shiptoscreen(ship,compos):
    compos.empty()
    grid=makegrid()
    #say: [['rocketturret', 'mediumflt'], ['basicturret', ''], ['', '']]
    rowcount=0
    colcount=0
    for row in ship:#3 rows, outer part of list
        for col in row:
            if col=="":
                pass
            else:
                newpart=col#component name
                newcomponent=component(newpart,0,False)
                print(rowcount,colcount)
                newcomponent.deposit(rowcount,colcount,grid,True)#x,y,grid,xyascoord
                compos.add(newcomponent)
                grid[rowcount][colcount]=newcomponent
                colcount+=1
        rowcount+=1
        colcount=0
    return grid
                

def setupleftedge(compos,components,startfrom):#say is 1 then miss item 0
    activecompos=[]
    count=0
    for x in components[startfrom::]:
        activecompos.append(x)
        if component=="mediumflt":
            cpt1=component(x,count,3)
        else:
            cpt1=component(x,count)
        compos.add(cpt1)
        count+=1
        if count==COMPONUM:
            break#only 5 slots at moment
    return activecompos

def genshipgrid(grid):#component objects-> grid of compo NAMES
    new=[]
    for x in range(len(grid)):
        new.append([])
        for y in grid[x]:
            if y=="":
                new[x].append("")
            else:
                new[x].append(y.part)#name of component eg medflt
    return new
        
def checkclickedbutton(y,grid):#    x always in range if get here
    if y>=40 and y<=90:#battle
        return "battle",None
        
    if y>=140 and y<=190:#save
        ship=genshipgrid(grid)
        with open("saves.txt",mode="a") as file:
            for x in ship:
                for y in x:
                    file.write(y+"\n")#6 lines, each holds string
        return "save",None
    
    elif y>=240 and y<=290:#load
        count=0
        with open("saves.txt") as file:
            for x in file:
                count+=1
        data=count//(DESIGNCOLS*DESIGNROWS)#how many ships in save file
        return "load",data

    elif y>340 and y<390:
        return "tutorial",None

    else:
        return "",None

        
    


class component(pg.sprite.Sprite):#things on left side of screen
    def __init__(self,whichpart,initpos,displaypart=True):#initpos=1,2,3,4
        super(component,self).__init__()
        self.part=whichpart
        if whichpart!="mediumflt":
            self.size=1
        else:
            self.size=3
        try:
            self.sfc=pg.image.load(PATH+"designimg\\"+whichpart+".png").convert_alpha()
        except:
            self.sfc=pg.image.load(PATH+whichpart+".png").convert_alpha()

        ht=self.sfc.get_height()
        wid=self.sfc.get_width()
        if displaypart:
            if ht>wid:#high image
                ratio=(int(COMPOHT/ht*wid),COMPOHT)
            elif ht*1.4<wid:#very wide image
                ratio=(COMPOWIDE-20,int((COMPOWIDE-20)*ht/wid))
            else:#near square
                ratio=(int(COMPOWIDE*0.7),int(COMPOWIDE*0.7*ht/wid))

                
        else:#grid part
            if self.part=="basicturret":
                ratio=(int(SQWIDTH*self.size*wid/ht/1.4),int(SQHEIGHT*self.size/1.4))
            elif ht>wid:
                ratio=(int(SQWIDTH*self.size*wid/ht),SQHEIGHT*self.size)#basicturret too small, otherweapons also too small
            else:
                ratio=(SQWIDTH*self.size,int(SQHEIGHT*ht/wid*self.size))
            
        self.sfc=pg.transform.scale(self.sfc,ratio)       
        self.rect=self.sfc.get_rect()
        self.rect.center=(COMPOWIDE/2,COMPOHT/2+(COMPOHT+5)*initpos)
    

    def update(self):
        screen.blit(self.sfc,self.rect)


    def deposit(self,x,y,grid,xyascoord=False):
        adjust=0
        if x>COMPOWIDE-30 and x<monw-COMPOWIDE or xyascoord==True:#if outside del new part
            if xyascoord:
                num=x#whichrow of 2
                num2=y
            else:
                newx=x-COMPOWIDE
                num=newx//SQWIDTH
                if num>DESIGNROWS:#ie on 30 overdraft
                    num-=1
                if self.size>2:
                    num-=1
                if num<0 or (self.size>2 and num>DESIGNCOLS-3):
                    num=0#if too big move to left so fits on grid
                num2=math.floor(y/SQHEIGHT)#if 200 max is 01 then 0 ie top

            if self.part=="mediumflt" or self.part=="smallflt":
                num2=DESIGNROWS-1#place on bottom row
            elif num2==DESIGNROWS-1:
                num2-=1#if not float, cannot be in bottom row

            
            self.rect.x=COMPOWIDE+num*SQWIDTH
            self.rect.y=num2*SQHEIGHT

            ###############adjusts
            if self.part=="mediumengine":
                self.rect.y+=SQHEIGHT/DESIGNCOLS+50
            elif self.part=="smallengine":
                self.rect.y+=SQHEIGHT/DESIGNCOLS+20
            elif self.part=="basicturret":
                self.rect.y+=SQHEIGHT/3


                

            for each in range(self.size):#1 or 3 times,
                if grid[num+each][num2]!="":#kill sprite at square placing at, then to right if size 3
                    grid[num+each][num2].kill()
                    
            if grid[num-2][num2]!="":
                if grid[num-2][num2].size>2:
                    grid[num-2][num2].kill()
            if grid[num-1][num2]!="":#kill big part if place smaller part to right
                if grid[num-1][num2].size>2:
                    grid[num-1][num2].kill()
            

            grid[num][num2]=self#num is how far across, num2 is which row

                
            
        else:
            self.kill()#maybe x need both lines
            














def main():
    beat = pg.mixer.Sound(PATH+'garage.ogg')
    beat.play()
    grid=makegrid()
    gridparts=pg.sprite.Group()#on the left
    compos=pg.sprite.Group()#on the grid
    dragcomp=data=btnevent=None
    
    components=("basicturret","mortar","rocketturret","mediumflt","smallflt","metalarmour","woodarmour","smallengine","mediumengine","pedestal","darkarmour")#propellor build in when place engine
    enemies=([['basicturret','smallflt'],['',''],['','']],#right side front of ship
             [['smallengine','smallflt'],['basicturret','smallflt'],['','']],
             [['basicturret','mediumflt'],['woodarmour',''],['woodarmour','']],
             [['smallengine','mediumflt'],['rocketturret',''],['woodarmour','']],
             [['mediumengine','mediumflt'],['rocketturret',''],['metalarmour','']],
             [['basicturret', 'pedestal', 'mediumflt'], ['', 'mediumengine', ''], ['', 'metalarmour', ''], ['', '', '']],
             [['darkarmour', 'mediumengine', 'mediumflt'], ['rocketturret', 'metalarmour', ''], ['mortar', 'metalarmour', ''], ['', '', '']],
             [['smallengine', 'woodarmour', ''], ['', 'mortar', 'mediumflt'], ['mortar', 'metalarmour', ''], ['', 'metalarmour', '']],
             [['metalarmour', 'smallengine', 'mediumflt'], ['metalarmour', 'basicturret', ''], ['metalarmour', 'basicturret', ''], ['rocketturret', 'metalarmour', '']],
             [['rocketturret', 'pedestal', 'mediumflt'], ['', 'smallengine', ''], ['', 'mortar', ''], ['rocketturret', 'darkarmour', 'smallflt']],
             [['', 'mediumengine', 'mediumflt'], ['', 'rocketturret', ''], ['', 'rocketturret', ''], ['darkarmour', 'darkarmour', 'smallflt']],
             [['rocketturret', 'mediumengine', 'mediumflt'], ['darkarmour', 'rocketturret', ''], ['darkarmour', 'rocketturret', ''], ['darkarmour', 'rocketturret', 'smallflt']])

    width,height=screen.get_size()
    running=True
    clock=pg.time.Clock()

    scrollcount=0
    maxscroll=len(components)-COMPONUM
    activecompos=setupleftedge(gridparts,components,0)
    
    ###########TEXT
    battle=font.render("Battle!",False,(0,0,0))          
    battlerect=battle.get_rect()
    battlerect.x=TEXTX+5
    battlerect.y=45


    save=font.render("Save",False,(0,0,0))          
    saverect=save.get_rect()
    saverect.x=TEXTX+5
    saverect.y=145

    load=font.render("Load",False,(0,0,0))          
    loadrect=load.get_rect()
    loadrect.x=TEXTX+5
    loadrect.y=245

    tutorial=font.render("Tutorial",False,(0,0,0))          
    tutorialrect=load.get_rect()
    tutorialrect.x=TEXTX+5
    tutorialrect.y=345

    tut1=font.render("A and D to move ship.",False,(0,0,0))
    tut1rect=tut1.get_rect()
    tut1rect.center=(monw/2,monh/2-150)
    tut2=font.render("S and W to elevate guns.",False,(0,0,0))
    tut2rect=tut2.get_rect()
    tut2rect.center=(monw/2,monh/2-50)
    tut3=font.render("Space to fire.",False,(0,0,0))
    tut3rect=tut3.get_rect()
    tut3rect.center=(monw/2,monh/2+50)

    info=font.render("Saved",False,(0,0,0))
    inforect=info.get_rect()
    inforect.center=(monw/2,monh/2)

    rejected=bigfont.render("Rejected",False,(255,0,0))
    rejectedrect=rejected.get_rect()
    rejectedrect.center=(monw/2,monh/2)

    
    infoflag=False
    infoflag2=False

    

    
    

    while running:
        clock.tick(FRAMERATE)
        for event in pg.event.get():
            if event.type==pg.QUIT:
                    running=False
            elif event.type==KEYDOWN:
                if event.key== K_ESCAPE:
                    running=False
            elif event.type==pg.VIDEORESIZE:
                width,height=screen.get_size()




            ##################MOUSE
            elif event.type==pg.MOUSEBUTTONDOWN:#mouse ets
                x,y=pg.mouse.get_pos()
                if btnevent=="tutorial" or btnevent=="rejected":
                    btnevent=None
                ###SCROLL
                if event.button == 5:#scroll down
                    scrollcount+=1
                    if scrollcount<=maxscroll:#works on 3 ie max
                        gridparts.empty()
                        activecompos=setupleftedge(gridparts,components,scrollcount)
                    else:
                        scrollcount=maxscroll
                if event.button == 4:
                    scrollcount-=1
                    if scrollcount>=0:
                        gridparts.empty()
                        activecompos=setupleftedge(gridparts,components,scrollcount)
                    else:
                        scrollcount=0




                clickon=True
                if btnevent is not None and btnevent is not "save":#check if click on load/battle number
                    if y>monh/2-100:
                        offset=x+LOADADJUST-monw/2#how far right of center
                        
                        if data<=6 and y<monh/2+20:
                            realnum=getrealnum(data,offset)
                            
                            
                        elif data>6 and y<monh/2+110:#topline 1-> data//2 if len 7 then 1 to 4
                            if y<monh/2+20:#top line
                                toplinemax=data//2+1
                                realnum=getrealnum(toplinemax,offset)
                            else:
                                realnum=data//2+1+getrealnum(data-data//2-1,offset)#ie 4 (on topline)+ 7-4 (ie the 3 on the bottom line)
                        else:
                            clickon=False
                        if clickon:
                            if btnevent=="battle":
                                ship=genshipgrid(grid)
                                enship=enemies[realnum-1]
                                beat.stop()
                                winner=byob.main(ship,enship)
                                resume=byob_ending.main(winner)
                                beat.play()
                                if not resume:
                                    running=False
                        
                            elif realnum>0 and realnum<=data:
                                ship=loadship(realnum)
                                grid=shiptoscreen(ship,compos)
                    btnevent=None


                                


                ###LEFT BAR
                if x<=COMPOWIDE:#get component from 
                    num=int(y//((monh)/COMPONUM))#how far down on left side
                    newpart=activecompos[num]
                    dragcomp=component(newpart,num,False)#new compo to drag
                    compos.add(dragcomp)

                elif x<=COMPOWIDE+DESIGNWIDTH:
                    ###DRAG SOMETHING ON GRID       
                    num=(x-COMPOWIDE)//SQWIDTH#0,1 or 2
                    num2=y//SQHEIGHT#0 or 1
                    if grid[num][num2]!="":#num is how far right, num2 is how high in col
                        dragcomp=grid[num][num2]
                        grid[num][num2]=""     
                    elif num>0:
                        if grid[num-1][num2]!="":
                            if grid[num-1][num2].size>2:#pick up medflt
                                dragcomp=grid[num-1][num2]
                                grid[num-1][num2]=""
                        if num>1:
                            if grid[num-2][num2]!="":
                                if grid[num-2][num2].size>2:
                                    dragcomp=grid[num-2][num2]
                                    grid[num-2][num2]=""
                            
                            
                else:
                    ###########LOAD SAVE BATTLE
                    btnevent,data=checkclickedbutton(y,grid)#"save","load"+data,None or "battle"
                    if btnevent=="save":
                        infoflag=infoflag2=True
                        
                    elif btnevent=="battle":
                        if anyfloat(grid):
                            data=len(enemies)
                        else:
                            btnevent="rejected"
                            
                    #lines of load slots or enemies
                    if btnevent=="battle" or btnevent=="load":
                        line=line2=""
                        for x in range(data):
                            if data>6 and x>data//2:
                                line2+=str(x+1)+"   "
                            else:
                                line+=str(x+1)+"   "

                        loadline=bigfont.render(line,False,(0,0,0))
                        loadlinerect=loadline.get_rect()
                        loadlinerect.center=(monw/2+LOADADJUST,monh/2-50)#40 as adjust
                        if data>6:
                            loadlinewide=(data//2+1)*140
                            loadline2=bigfont.render(line2,False,(0,0,0))
                            loadline2rect=loadline.get_rect()
                            loadline2rect.center=(monw/2+LOADADJUST,monh/2+50)
                        else:
                            loadlinewide=data*140
                                       



                    

                    

            elif event.type==pg.MOUSEBUTTONUP:
                if dragcomp!=None:
                    x,y=pg.mouse.get_pos()
                    dragcomp.deposit(x,y,grid)
                    dragcomp=None

            elif event.type == pg.MOUSEMOTION:
                if dragcomp!=None:
                    mouse=pg.mouse.get_pos()
                    if dragcomp.part=="basicturret":#or center too far right
                        dragcomp.rect.center=(mouse[0]+150,mouse[1])
                    else:
                        dragcomp.rect.center=(mouse[0],mouse[1])









        #################screen REFRESH
        if btnevent=="tutorial":
            screen.blit(tut1,tut1rect)
            screen.blit(tut2,tut2rect)
            screen.blit(tut3,tut3rect)
        elif btnevent=="rejected":
            screen.blit(rejected,rejectedrect)
            
        else: 
            screen.fill((255,255,255))
            pg.draw.rect(screen,(220,220,255),(0,0,COMPOWIDE,monh+60))
            for x in compos:
                x.update()
            for x in gridparts:
                x.update()


            pg.draw.rect(screen,(255,150,150),(TEXTX,40,COMPOWIDE,50))#margin of 10
            screen.blit(battle,battlerect)
            pg.draw.rect(screen,(255,150,150),(TEXTX,140,COMPOWIDE,50))
            screen.blit(save,saverect)
            pg.draw.rect(screen,(255,150,150),(TEXTX,240,COMPOWIDE,50))
            screen.blit(load,loadrect)
            pg.draw.rect(screen,(255,150,150),(TEXTX,340,COMPOWIDE,50))
            screen.blit(tutorial,tutorialrect)
            
            for y in range(DESIGNROWS-1):#horizontal lines
                pos=SQHEIGHT*(y+1)#1/2
                pg.draw.rect(screen,(100,100,255),(COMPOWIDE,pos,DESIGNWIDTH,4))
            for x in range(DESIGNCOLS-1):
                pos=COMPOWIDE+SQWIDTH*(x+1)
                pg.draw.rect(screen,(100,100,255),(pos,0,4,monw))
            if infoflag:
                infoflag=False
                infotimer=time()
            if infoflag2:
                if time()-infotimer<1.5:
                    screen.blit(info,inforect)
                else:
                    infoflag2=False
                    
            ####LOAD BOXES     
            elif btnevent=="load" or btnevent=="battle":
                if data<=6:
                    pg.draw.rect(screen,(255,0,0),(monw/2-loadlinewide/2+20,monh/2-100,loadlinewide,120))
                else:
                    pg.draw.rect(screen,(255,0,0),(monw/2-loadlinewide/2+20,monh/2-100,loadlinewide,210))
                    screen.blit(loadline2,loadline2rect)
                screen.blit(loadline,loadlinerect)

            
                





        
        pg.display.update()
    pg.quit()
main()
